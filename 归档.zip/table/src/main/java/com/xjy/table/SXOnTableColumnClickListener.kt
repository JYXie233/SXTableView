package com.xjy.table

interface SXOnTableColumnClickListener {
    fun onColumnClick(row: Int)
}