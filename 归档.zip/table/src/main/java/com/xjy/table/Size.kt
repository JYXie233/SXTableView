package com.xjy.table

data class Size(val width:Int, val height: Int)